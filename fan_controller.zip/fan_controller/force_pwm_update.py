import serial
import sys
port = "/dev/tty/ACMO"
ser = serial.Serial(port, 9600)

try:
    fan_nr = sys.argv[1]
    pwm_sig = sys.argv[2]
except IndexError:
    print("please specify fan-nr[3(fogfan),9(in- & outtake), 10(turbulence)] and pwm[0-100%]")
pwm_sig = min(pwm_sig, 100
)

ser.write(str(fan_nr) + "," + str(pwm_sig * 10.23).encode())